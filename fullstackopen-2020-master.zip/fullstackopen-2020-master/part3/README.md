### Part 3 Programming a server with NodeJS and Express

## Solutions to exercises:

The exercises for this part of the course consist of building a REST backend for the frontend UI built in the last part.
It requires its own repository, therefore it is not included in this main repo and can be found [here](https://github.com/orrsteinberg/fullstackopen-2020-part3) instead.
